# companion-module-studiopro

This module will allow you to control StudioPro using the built-in websocket plugin.

